prettyhtmlfrompandas makes a beautiful html page with the pandas dataframe that you provide.
## Documentation

### One Command You Need

```
from prettyhtmlfrompandas import makehtml
makehtml(df,name)
```
Replace `df` with the variable that contains the pd.dataframe(...)
Replace `name` with the heading that you want for the html file.
